"use client"
import { useSession, signIn, signOut } from "next-auth/react"
import React from 'react'
import { useRouter } from "next/navigation"
import Dashboard from "@/components/Dashboard"


const page = () => {
    const { data: session } = useSession();
    // if (!session) {
    //     const router = useRouter();
    //     router.push('/login')
    // }
    return (
        <>
          <Dashboard/>  
        </>
    )
}

export default page
