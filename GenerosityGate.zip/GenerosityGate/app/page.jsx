import Image from "next/image";
import Temp from "@/components/Temp";
export default function Home() {

  return (
    <>
    <Temp/>
    </>
  );
}
