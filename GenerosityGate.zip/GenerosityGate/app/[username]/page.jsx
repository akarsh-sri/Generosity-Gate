// "use client"
import PaymentPage from '@/components/PaymentPage'
import React from 'react'
// import { useSession, signIn, signOut } from "next-auth/react"
// import { useRouter } from "next/navigation"
import User from '../models/User'
import { notFound } from 'next/navigation'
import connectDB from '../db/connectDb'

const Username = async ({ params }) => {
  // const { data: session } = useSession();
  // if (!session) {
  //   const router = useRouter();
  //   router.push('/login')
  // }

  const check = async () => {
    await connectDB();
    let u = await User.findOne({ username: params.username });
    if (!u) {
      return notFound();
    }
  }
  await check();

  return (
    <PaymentPage params={params} />
  )
}

export default Username
