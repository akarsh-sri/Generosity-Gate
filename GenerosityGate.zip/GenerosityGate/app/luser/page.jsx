import React from 'react'

const Luser = () => {
  return (
    <div>Luser</div>
  )
}

export default Luser