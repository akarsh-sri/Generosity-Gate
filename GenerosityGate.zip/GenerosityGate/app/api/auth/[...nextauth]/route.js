import NextAuth from 'next-auth'
import GitHubProvider from "next-auth/providers/github";
import mongoose from 'mongoose';
import User from '@/app/models/User';
import Payment from '@/app/models/Payment';
import connectDB from '@/app/db/connectDb';

export const authoptions = NextAuth({
  providers: [
    // OAuth authentication providers...
    GitHubProvider({
      clientId: "Ov23liiMfGyA4KGSgaNP",
      clientSecret: "4adf1614499028a50f08ecfd5eefff643066dd8a"
    }),
  ],
  callbacks: {
    async signIn({ user, account, profile, email, credentials }) {
      if (account.provider == "github") {
        await connectDB();
        const currentUser = await User.findOne({ email: email });
        if (!currentUser) {
          const newUser =await User.create({
            email: user.email,
            username: user.email.split("@")[0],
          })
          user.name = newUser.username
          await newUser.save();
        }
        return true;
      }
    },
    async session({ session, user, token }) {
      const dbUser = await User.findOne({ email: session.user.email });
      session.user.name = dbUser.username
      return session
    },
  }
})

export { authoptions as GET, authoptions as POST }