"use client"
import React from 'react'
import { useState } from 'react'
import { useEffect } from 'react'
import { f } from '@/actions/useraction'
import { useRouter } from 'next/navigation'


const Temp = () => {
    const router = useRouter();
    const [uu, setuu] = useState([])

    useEffect(() => {
        foo();
    }, [])

    const foo = async () => {
        let u = await f();

        setuu(u);
    }
    return (
        <div>
            <div className="flex justify-center flex-col items-center text-white h-[44vh] gap-4">
                <div className="font-bold text-5xl font-serif">Your Gateway to Generosity</div>
                <div className='w-1/2'>
                    <p className="font-mono text-center mx-2">Welcome to GenerosityGate, where your contributions turn dreams into reality. Whether supporting a personal cause, a community project, or a global initiative, every donation makes a meaningful impact. Join us in creating a world where kindness and compassion pave the way for a brighter future. Together, we can open doors to endless possibilities.</p>
                </div>

                <div>
                    <button type="button" class="text-white bg-gradient-to-br from-purple-600 to-blue-500 hover:bg-gradient-to-bl focus:ring-4 focus:outline-none focus:ring-blue-300 dark:focus:ring-blue-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center me-2 mb-2">Start Here</button>
                    <button type="button" class="text-white bg-gradient-to-br from-purple-600 to-blue-500 hover:bg-gradient-to-bl focus:ring-4 focus:outline-none focus:ring-blue-300 dark:focus:ring-blue-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center me-2 mb-2">Read More</button>
                </div>
            </div>
            <div className="bg-white h-1 opacity-10"></div>
            <div>
                <div className='text-center text-3xl font-bold my-2'>Our Members</div>
                <div className='border p-5 w-1/2 mx-auto my-10'>
                    {
                        [...new Set(uu.map(item => item.username))].map((username, ind) => (
                            <div key={ind}>
                                <div className='flex justify-between'>
                                    <span className='font-bold text-xl'>@{username}</span>
                                    <span><button onClick={() => router.push(`/${username}`)} type="button" class="text-white bg-gradient-to-br from-purple-600 to-blue-500 hover:bg-gradient-to-bl focus:ring-4 focus:outline-none focus:ring-blue-300 dark:focus:ring-blue-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center me-2 mb-2">Visit Page</button></span>
                                </div>

                            </div>
                        ))
                    }
                </div>

            </div>
        </div>
    )
}

export default Temp