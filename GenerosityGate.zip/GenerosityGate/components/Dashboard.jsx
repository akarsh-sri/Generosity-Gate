"use client"
import { useEffect, useState } from 'react'
import { useSession, signIn, signOut } from "next-auth/react"
import { useRouter } from 'next/navigation'
import React from 'react'
import { fetchUser, UpdateProfile } from '@/actions/useraction'

const Dashboard = () => {
    const { data: session, update } = useSession();
    const [form, setform] = useState({});
    const router = useRouter();
    useEffect(() => {
        if (!session) {
            // const router = useRouter();
            // router.push('/login')
        }
        getData();
    }, [router, session])

    const handlechange = (e) => {
        // console.log(e.target.value);
        setform[{ ...form, [e.target.name]: e.target.value }]
    }

    const getData = async () => {
        if (session) {
            let u = await fetchUser(session.user.name);
            setform(u);
        }

    }

    const handlesubmit = async (e) => {
        console.log(e);
        // update();
        let a = await UpdateProfile(e, session.user.name);
        // console.log(form.razorpayid);
        // console.log(form.razorpaysecret);
        // console.log(form.name);
        alert("Profile Updated");
    }

    return (
        <div>
            <h1 className="text-4xl font-bold text-center">Welcome to your Dashboard</h1>
            <form className='max-w-2xl mx-auto' action={handlesubmit}>
                <div className='my-2'>
                    <label htmlFor="name" className='block font-bold mb-2'>Name</label>
                    <input defaultValue={form.name ? form.name : ''} className='p-2 rounded-xl block w-full bg-slate-600 text-white' type="text" name='name' id='name' onChange={handlechange} />
                </div>
                <div className='my-2'>
                    <label htmlFor="email" className='block font-bold mb-2'>Email</label>
                    <input defaultValue={form.email ? form.email : ''} className='p-2 rounded-xl block w-full bg-slate-600 text-white' type="text" name='email' id='email' onChange={handlechange} />
                </div>
                <div className='my-2'>
                    <label htmlFor="username" className='block font-bold mb-2'>UserName</label>
                    <input defaultValue={form.username ? form.username : ''} className='p-2 rounded-xl block w-full bg-slate-600 text-white' type="text" name='username' id='username' onChange={handlechange} />
                </div>
                <div className='my-2'>
                    <label htmlFor="profile" className='block font-bold mb-2'>Profile</label>
                    <input defaultValue={form.profile ? form.profile : ''} className='p-2 rounded-xl block w-full bg-slate-600 text-white' type="text" name='profile' id='profile' onChange={handlechange} />
                </div>
                <div className='my-2'>
                    <label htmlFor="cover" className='block font-bold mb-2'>Cover</label>
                    <input defaultValue={form.cover ? form.cover : ''} className='p-2 rounded-xl block w-full bg-slate-600 text-white' type="text" name='cover' id='cover' onChange={handlechange} />
                </div>
                
                <div className='my-2'>
                    <label htmlFor="razorpayid" className='block font-bold mb-2'>RazorPay ID</label>
                    <input defaultValue={form.razorpayid ? form.razorpayid : ''} className='p-2 rounded-xl block w-full bg-slate-600 text-white' type="text" name='razorpayid' id='razorpayid' onChange={handlechange} />
                </div>
                <div className='my-2'>
                    <label htmlFor="razorpaysecret" className='block font-bold mb-2'>RazorPay Secret</label>
                    <input defaultValue={form.razorpaysecret ? form.razorpaysecret : ''} className='p-2 rounded-xl block w-full bg-slate-600 text-white' type="text" name='razorpaysecret' id='razorpaysecret' onChange={handlechange} />
                </div>
                <div className='flex justify-center my-5'>
                    <button type="submit" className="text-white bg-gradient-to-br from-purple-600 to-blue-500 hover:bg-gradient-to-bl focus:ring-4 focus:outline-none focus:ring-blue-300 dark:focus:ring-blue-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center me-2 mb-2">Save</button>
                </div>
            </form>
        </div>
    )
}

export default Dashboard
